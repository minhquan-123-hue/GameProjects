PONG (Learning Project)

A simple Pong game written in C++ using SDL2.
Made for learning purposes.

Controls:
- W / S : Left paddle
- Up / Down : Right paddle
- R : BACK to MENU
- 1 / 2 : choose level ONE_PLAYER or TWO_PLAYER

Platform:
- Linux x86_64

This is not a commercial game.

